const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const User = require("./models/User");
const Section = require("./models/Section");

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/caps_db");
    console.log("✅ Connected to MongoDB");

    // Clear existing users and school years
    await User.deleteMany({});
    await require("./models/SchoolYear").deleteMany({});
    await Section.deleteMany({});
    console.log("🗑️  Cleared existing users, sections, and school years");

    // Hash passwords
    const hashedAdminPassword = await bcrypt.hash("admin123", 10);
    const hashedStaffPassword = await bcrypt.hash("staff123", 10);

    // Create school years
    const SchoolYear = require("./models/SchoolYear");
    const sy2025 = await SchoolYear.create({ year: "2025-2026" });
    const sy2026 = await SchoolYear.create({ year: "2026-2027" });

    // Create admin and staff
    const adminUser = {
      role: "admin",
      username: "admin1",
      password: hashedAdminPassword,
      name: "Admin User"
    };
    const staffUser = {
      role: "staff",
      username: "staff1",
      password: hashedStaffPassword,
      name: "Staff User"
    };

    // Create three students under 2025-2026 with per-semester payment records
    const students = [
      {
        role: "student",
        usn: "USN101",
        name: "Student One",
        course: "WADT",
        section: "WADT 3D",
        schoolYear: "2025-2026",
        paymentsPerSemester: {
          sem1: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          },
          sem2: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          }
        }
      },
      {
        role: "student",
        usn: "USN102",
        name: "Student Two",
        course: "WADT",
        section: "WADT 3A",
        schoolYear: "2025-2026",
        paymentsPerSemester: {
          sem1: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          },
          sem2: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          }
        }
      },
      {
        role: "student",
        usn: "USN103",
        name: "Student Three",
        course: "WADT",
        section: "WADT 3B",
        schoolYear: "2025-2026",
        paymentsPerSemester: {
          sem1: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          },
          sem2: {
            module: { status: "unpaid", datePaid: null },
            tshirt: { status: "unpaid", datePaid: null },
            tenk: { amount: "P200", status: "unpaid", datePaid: null },
            fortyFiveHundred: { amount: "P200", status: "unpaid", datePaid: null }
          }
        }
      }
    ];

    // Insert all users
    await User.insertMany([adminUser, staffUser, ...students]);

    // Seed default sections for WADT
    const defaultSections = [
      { course: "WADT", name: "WADT 3D" },
      { course: "WADT", name: "WADT 3A" },
      { course: "WADT", name: "WADT 3B" }
    ];
    await Section.insertMany(defaultSections);
    console.log("✅ Test users and school years added successfully");

    console.log("\n📋 Test Credentials:");
    console.log("Admin - Username: admin1 | Password: admin123");
    console.log("Staff - Username: staff1 | Password: staff123");
    console.log("Student - USN: USN001 | Name: Disa Mae Columnas | Course: WADT");
    console.log("Student - USN: USN002 | Name: Jane Smith | Course: WADT");

    mongoose.connection.close();
  } catch (err) {
    console.error("❌ Error seeding database:", err.message);
    process.exit(1);
  }
};

seedDatabase();
