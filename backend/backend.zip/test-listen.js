const http = require('http');
const port = 5000;
const server = http.createServer((req, res) => {
  if (req.url === '/ping') res.end('pong');
  else res.end('ok');
});
server.listen(port, () => console.log('test-listen running on', port));
setTimeout(()=>console.log('still alive'), 10000);
