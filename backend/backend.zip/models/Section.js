const mongoose = require("mongoose");

const SectionSchema = new mongoose.Schema({
  course: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  }
});

module.exports = mongoose.model("Section", SectionSchema);
