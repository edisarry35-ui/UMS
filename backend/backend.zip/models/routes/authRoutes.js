const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const User = require("../User");
const Section = require("../Section");
const Announcement = require("../Announcement");
const csv = require("csv-parse/sync");

const router = express.Router();

// GET / → show API status
router.get("/", (req, res) => {
  res.send("Auth API is running");
});

// POST /login → authenticate user
router.post("/login", async (req, res) => {
  const { role, username, password, usn, name } = req.body;

  let user;
  if (role === "student") {
    user = await User.findOne({ usn, name });
  } else {
    user = await User.findOne({ username });
    if (user && !(await bcrypt.compare(password, user.password))) {
      user = null;
    }
  }

  if (!user) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );

  res.json({ token, role: user.role });
});

// GET /students → get all students
router.get("/students", async (req, res) => {
  try {
    const students = await User.find({ role: "student" });
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /course/:course/sections → list sections for a course
router.get("/course/:course/sections", async (req, res) => {
  try {
    const courseName = req.params.course;
    const sections = await Section.find({ course: courseName });
    res.json(sections);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /course/:course/sections → add a new section for a course
router.post("/course/:course/sections", async (req, res) => {
  try {
    const courseName = req.params.course;
    const { name } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ message: "Section name is required" });
    }

    // Prevent duplicate section names for same course
    const existing = await Section.findOne({ course: courseName, name });
    if (existing) {
      return res.status(409).json({ message: "Section already exists" });
    }

    const section = new Section({ course: courseName, name });
    await section.save();
    res.status(201).json(section);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /student/:id → get student details
router.get("/student/:id", async (req, res) => {
  try {
    const student = await User.findById(req.params.id);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /user/:id -> update user fields (name, usn, password, section, course)
router.put("/user/:id", async (req, res) => {
  try {
    const { name, usn, password, section, course } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    if (name && typeof name === "string") user.name = name;
    if (usn && typeof usn === "string") user.usn = usn;
    if (password && typeof password === "string") {
      const hashed = await bcrypt.hash(password, 10);
      user.password = hashed;
    }
    if (section && typeof section === "string") user.section = section;
    if (course && typeof course === "string") user.course = course;

    await user.save();
    res.json({ message: "User updated", user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /user/:id -> delete user
router.delete("/user/:id", async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json({ message: "User deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /student/:id/payment → update payment status
router.put("/student/:id/payment", async (req, res) => {
  try {
    const { paymentType, status, datePaid } = req.body;
    
    const student = await User.findById(req.params.id);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Map payment type to field name
    const paymentFieldMap = {
      module: "module",
      tshirt: "tshirt",
      tenk: "tenk",
      fortyFiveHundred: "fortyFiveHundred"
    };

    const fieldName = paymentFieldMap[paymentType];
    if (!fieldName) {
      return res.status(400).json({ message: "Invalid payment type" });
    }

    // Update the payment status and date
    if (fieldName === "module" || fieldName === "tshirt") {
      student[fieldName].status = status;
      student[fieldName].datePaid = status === "paid" ? (datePaid || new Date()) : null;
    } else {
      student[fieldName].status = status;
      student[fieldName].datePaid = status === "paid" ? (datePaid || new Date()) : null;
    }

    await student.save();
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /announcements → create an announcement (staff/admin)
router.post("/announcements", async (req, res) => {
  try {
    const { title, content, author, role } = req.body;
    console.log("POST /announcements received:", { title, content, author, role });
    
    if (!title || !content || !author || !role) {
      console.log("Missing required fields:", { title: !!title, content: !!content, author: !!author, role: !!role });
      return res.status(400).json({ message: "Missing required fields" });
    }

    // If admin posts, auto-approve; staff posts remain pending
    const announcementData = {
      title,
      content,
      author,
      role,
    };

    if (role === "admin") {
      announcementData.status = "approved";
      announcementData.approvedBy = author;
      announcementData.approvalDate = new Date();
    } else {
      announcementData.status = "pending";
    }

    const announcement = new Announcement(announcementData);
    await announcement.save();
    console.log("Announcement saved successfully:", announcement);
    res.status(201).json(announcement);
  } catch (err) {
    console.error("Error creating announcement:", err);
    res.status(500).json({ message: err.message });
  }
});

// GET /announcements/pending → get pending announcements (admin only)
router.get("/announcements/pending", async (req, res) => {
  try {
    const pending = await Announcement.find({ status: "pending" }).sort({ createdAt: -1 });
    res.json(pending);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /announcements → get all approved announcements (all users)
router.get("/announcements", async (req, res) => {
  try {
    const announcements = await Announcement.find({ status: "approved" }).sort({ approvalDate: -1 });
    res.json(announcements);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /announcements/:id/approve → approve an announcement (admin only)
router.put("/announcements/:id/approve", async (req, res) => {
  try {
    const { approvedBy } = req.body;
    if (!approvedBy) {
      return res.status(400).json({ message: "approvedBy is required" });
    }

    const announcement = await Announcement.findById(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }

    announcement.status = "approved";
    announcement.approvedBy = approvedBy;
    announcement.approvalDate = new Date();
    await announcement.save();

    res.json(announcement);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /announcements/:id/reject → reject an announcement (admin only)
router.put("/announcements/:id/reject", async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }

    announcement.status = "rejected";
    await announcement.save();

    res.json(announcement);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /bulk-import-students → bulk import students from CSV/Excel file
router.post("/bulk-import-students", async (req, res) => {
  try {
    if (!req.files || !req.files.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const file = req.files.file;
    const fileContent = file.data.toString("utf8");

    // Parse CSV content
    const records = csv.parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });

    if (records.length === 0) {
      return res.status(400).json({ message: "CSV file is empty" });
    }

    // Validate headers
    const requiredHeaders = ["name", "usn", "section", "course"];
    const firstRecord = records[0];
    const missingHeaders = requiredHeaders.filter(header => !(header in firstRecord));
    
    if (missingHeaders.length > 0) {
      return res.status(400).json({ 
        message: `Missing required columns: ${missingHeaders.join(", ")}. Required: name, usn, section, course` 
      });
    }

    // Process and validate records
    const results = { success: [], errors: [] };
    for (let i = 0; i < records.length; i++) {
      const record = records[i];
      const rowNum = i + 2; // row number in spreadsheet (accounting for header)

      // Trim all values
      const name = record.name?.trim();
      const usn = record.usn?.trim();
      const section = record.section?.trim();
      const course = record.course?.trim();

      // Validate required fields
      if (!name || !usn || !section || !course) {
        results.errors.push({
          row: rowNum,
          reason: "Missing required fields (name, usn, section, course)"
        });
        continue;
      }

      try {
        // Check if student already exists
        const existing = await User.findOne({ usn });
        if (existing) {
          results.errors.push({
            row: rowNum,
            reason: `Student with USN ${usn} already exists`
          });
          continue;
        }

        // Create new student
        const student = new User({
          role: "student",
          name,
          usn,
          section,
          course,
          module: { status: "unpaid", datePaid: null },
          tshirt: { status: "unpaid", datePaid: null },
          tenk: { status: "unpaid", amount: "P200", datePaid: null },
          fortyFiveHundred: { status: "unpaid", amount: "P200", datePaid: null }
        });

        await student.save();
        results.success.push({ row: rowNum, usn, name });
      } catch (err) {
        results.errors.push({
          row: rowNum,
          reason: err.message || "Failed to create student"
        });
      }
    }

    res.json({
      message: `Import completed: ${results.success.length} success, ${results.errors.length} errors`,
      success: results.success,
      errors: results.errors
    });
  } catch (err) {
    console.error("Error in bulk import:", err);
    res.status(500).json({ message: "Error processing file: " + err.message });
  }
});

// POST /register → create a new user (admin only)
router.post("/register", async (req, res) => {
  try {
    const { role, username, password, name, usn } = req.body;

    if (!role) {
      return res.status(400).json({ message: "Role is required" });
    }

    let user;

    if (role === "student") {
      // Student registration requires name and usn
      if (!name || !usn) {
        return res.status(400).json({ message: "Name and USN are required for students" });
      }

      // Check if student already exists
      const existingStudent = await User.findOne({ usn });
      if (existingStudent) {
        return res.status(409).json({ message: "Student with this USN already exists" });
      }

      user = new User({
        role: "student",
        name,
        usn,
        // Initialize payment fields for student
        module: { status: "unpaid", amount: "₱1500", datePaid: null },
        tshirt: { status: "unpaid", amount: "₱350", datePaid: null },
        tenk: { status: "unpaid", amount: "₱10000", datePaid: null },
        fortyFiveHundred: { status: "unpaid", amount: "₱4500", datePaid: null }
      });
    } else if (role === "staff" || role === "admin") {
      // Staff/Admin registration requires username and password
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required for staff/admin" });
      }

      // Check if user already exists
      const existingUser = await User.findOne({ username });
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      user = new User({
        role,
        username,
        password: hashedPassword
      });
    } else {
      return res.status(400).json({ message: "Invalid role" });
    }

    await user.save();
    res.status(201).json({ message: `${role.charAt(0).toUpperCase() + role.slice(1)} registered successfully`, user });
  } catch (err) {
    console.error("Error in registration:", err);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
