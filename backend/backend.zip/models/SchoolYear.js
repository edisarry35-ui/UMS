const mongoose = require("mongoose");

const SchoolYearSchema = new mongoose.Schema({
  year: {
    type: String,
    required: true
  }
});

module.exports = mongoose.model("SchoolYear", SchoolYearSchema);

