const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema({
  status: {
    type: String,
    enum: ["paid", "unpaid"],
    default: "unpaid"
  },
  datePaid: Date
});

const userSchema = new mongoose.Schema({
  role: {
    type: String,
    enum: ["admin", "staff", "student"],
    required: true
  },
  username: String,
  password: String,
  usn: String,
  name: String,
  section: String,
  course: String,
  // Optional reference to school year (string like "2025-2026" or ObjectId if you prefer)
  schoolYear: String,
  // Payments separated per semester
  paymentsPerSemester: {
    sem1: {
      module: paymentSchema,
      tshirt: paymentSchema,
      tenk: {
        amount: { type: String, default: "P200" },
        status: { type: String, enum: ["paid", "unpaid"], default: "unpaid" },
        datePaid: Date
      },
      fortyFiveHundred: {
        amount: { type: String, default: "P200" },
        status: { type: String, enum: ["paid", "unpaid"], default: "unpaid" },
        datePaid: Date
      }
    },
    sem2: {
      module: paymentSchema,
      tshirt: paymentSchema,
      tenk: {
        amount: { type: String, default: "P200" },
        status: { type: String, enum: ["paid", "unpaid"], default: "unpaid" },
        datePaid: Date
      },
      fortyFiveHundred: {
        amount: { type: String, default: "P200" },
        status: { type: String, enum: ["paid", "unpaid"], default: "unpaid" },
        datePaid: Date
      }
    }
  }
});

module.exports = mongoose.model("User", userSchema);
