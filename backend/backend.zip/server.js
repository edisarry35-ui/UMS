// server.js
require("dotenv").config(); // Load .env first

const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const fileUpload = require("express-fileupload");

const app = express();

// Confirm MONGO_URI is loaded
if (!process.env.MONGO_URI) {
  console.error("❌ MONGO_URI is not defined in your .env file");
  process.exit(1);
} else {
  console.log("✅ MONGO_URI loaded successfully");
}

// Connect to MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(fileUpload());

// Auth routes
const authRoutes = require("./models/routes/authRoutes");

// Direct ROOT (/) to authRoutes
app.use("/", authRoutes);

// Optional: still allow /api/auth if you want
app.use("/api/auth", authRoutes);

// Use PORT from .env if defined, else 5000
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
